import boto3
import os

transcribe_client = boto3.client('transcribe')
LANGUAGE_CODE = os.environ['LANGUAGE_CODE']

def lambda_handler(event, context):
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        name = key.split('/')[-1].split('.')[0]
        extension = key.split('.')[-1]
        object_url = f'https://s3.amazonaws.com/{bucket}/{key}'

        transcribe_client.start_transcription_job(
            TranscriptionJobName=name,
            LanguageCode=LANGUAGE_CODE,
            MediaFormat='wav',
            Media={
                'MediaFileUri': object_url
            })
