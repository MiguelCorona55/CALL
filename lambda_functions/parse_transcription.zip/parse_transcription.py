import json
import os

import boto3
import urllib3

BUCKET_NAME = os.environ['BUCKET_NAME_TRANSCRIPTIONS']

s3 = boto3.resource('s3')
transcribe = boto3.client('transcribe')

http = urllib3.PoolManager()


def lambda_handler(event, context):
    job_name = event['detail']['TranscriptionJobName']
    job = transcribe.get_transcription_job(TranscriptionJobName=job_name)
    uri = job['TranscriptionJob']['Transcript']['TranscriptFileUri']

    content = http.request('GET', uri).data.decode('UTF-8')
    data = json.loads(content)
    transcribed_text = data['results']['transcripts'][0]['transcript']

    object = s3.Object(BUCKET_NAME, 'transcriptions/' + job_name + "_output.txt")
    object.put(Body=transcribed_text)
